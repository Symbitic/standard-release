const fs = require('fs');
const util = require('util');

const readFile = util.promisify(fs.readFile);

function add(a, b) {
    return a + b;
}

function subtract(a, b) {
    a - b;
}

module.exports = {
    readFile,
    add,
    subtract,
};
